<?php $__env->startSection("content"); ?>
  <link href="<?php echo e(URL::asset("cms/jdih/styleindex.css")); ?>" rel="stylesheet">

  <body>

    <div class="container">
      <div class="content">
        <h1>JDIH Records</h1>
        <main class="table" id="customers_table">
          <?php if(session("success")): ?>
            <div style="color: green;"><?php echo e(session("success")); ?></div>
          <?php endif; ?>

          <button class="btn"><a href="<?php echo e(route("admin.jdih.create")); ?>">Create New JDIH Record</a></button>
          <div class="container">
            <div class="row justify-content-center">
              <div class="col-md-12">
                <div class="card">
                  <div class="card-header">List JDIH</div>

                  <div class="table__body">
                    <table class="item" border="1">
                      <thead>
                        <tr>
                          <th>No</th>
                          <th>Tahun</th>
                          <th>Jenis Peraturan</th>
                          <th>Nama Peraturan</th>
                          <th>Tanggal Disahkan</th>
                          <th>File Peraturan</th>
                          <th>File Naskah Akademik</th>
                          <th>File DIM</th>
                          <th>File Lainnya</th>
                          <th>Action</th> <!-- New column for actions -->
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $jdihRecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $jdih): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td><?php echo e($key + 1); ?></td>
                            <td><?php echo e($jdih->tahun); ?></td>
                            <td><?php echo e($jdih->jenisPeraturan->name); ?></td> <!-- Access jenisPeraturan relationship -->
                            <td><?php echo e($jdih->nama_peraturan); ?></td>
                            <td><?php echo e($jdih->tanggal_disahkan); ?></td>
                            <td><a href="<?php echo e(Storage::url($jdih->file_peraturan)); ?>" target="_blank">Download</a></td>
                            <td>
                              <?php if($jdih->file_naskah): ?>
                                <a href="<?php echo e(Storage::url($jdih->file_naskah)); ?>" target="_blank">Download</a>
                              <?php else: ?>
                                N/A
                              <?php endif; ?>
                            </td>
                            <td>
                              <?php if($jdih->file_inventarisasi): ?>
                                <a href="<?php echo e(Storage::url($jdih->file_inventarisasi)); ?>" target="_blank">Download</a>
                              <?php else: ?>
                                N/A
                              <?php endif; ?>
                            </td>
                            <td>
                              <?php if($jdih->file_lain->isNotEmpty()): ?>
                                <ul>
                                  <?php $__currentLoopData = $jdih->file_lain; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href="<?php echo e(Storage::url($file->nama_file)); ?>" target="_blank">Download <?php echo e($loop->iteration); ?></a></li>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                              <?php else: ?>
                                N/A
                              <?php endif; ?>
                            </td>
                            <td>
                              <a href="<?php echo e(route("admin.jdih.edit", $jdih->id)); ?>">Edit</a> |
                              <a href="<?php echo e(route("admin.jdih.delete", $jdih->id)); ?>">Delete</a>
                            </td>
                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>

    <script>
      var hamburger = document.querySelector(".hamburger");
      var wrapper = document.querySelector(".wrapper");
      var backdrop = document.querySelector(".backdrop");

      hamburger.addEventListener("click", function() {
        wrapper.classList.add("active");
      })

      backdrop.addEventListener("click", function() {
        wrapper.classList.remove("active");
      })
    </script>
  </body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("cms.layouts.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work&Internship\FH\main\coba1_backend\resources\views/cms/jdih/index.blade.php ENDPATH**/ ?>