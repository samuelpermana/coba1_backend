<?php $__env->startSection('content'); ?>
<link href="<?php echo e(asset("styletransparansi.css")); ?>" rel="stylesheet">
    <div class="container">
        <div class="header-revisi">
            <h1>Daftar Revisi Proposal</h1>
            <h2><?php echo e($proposal->judul); ?></h2>
        </div>

        <a href="<?php echo e(route(auth()->user()->role->role_slug . '.revisi.create', $proposal->id)); ?>" class="btn-revisi">Buat Revisi</a>

        <section class="table__body">
        <table class="table__body">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Komentar</th>
                    <th>Direvisi Oleh</th>
                    <th>Waktu Revisi</th>
                    <th>File Revisi</th>
                    <th>Judul Lama</th>
                    <th>Deskripsi Lama</th>
                    <th>File Lama</th>
                    <th>Judul Baru</th>
                    <th>Deskripsi Baru</th>
                    <th>File Baru</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $revisiProposals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $revisi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($revisi->komentar); ?></td>
                        <td><?php echo e($revisi->revisedBy->name); ?></td>
                        <td><?php echo e($revisi->created_at->format('d M Y H:i:s')); ?></td>
                        <td><a href="<?php echo e(Storage::url($revisi['file_revisi'])); ?>" target="_blank">Download</a></td>
                        <?php $__currentLoopData = $riwayatRevisi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $riwayat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($riwayat->revisi_id == $revisi->id): ?>
                                <td><?php echo e($riwayat->judul_lama); ?></td>
                                <td><?php echo e($riwayat->deskripsi_lama); ?></td>
                                <td><a href="<?php echo e(Storage::url($riwayat->file_lama)); ?>" target="_blank">Download</a></td>
                                <td><?php echo e($riwayat->judul_hasil_revisi ?? ''); ?></td>
                                <td><?php echo e($riwayat->deskripsi_hasil_revisi ?? ''); ?></td>
                                <td>
                                    <?php if($riwayat->file_hasil_revisi): ?>
                                        <a href="<?php echo e(Storage::url($riwayat->file_hasil_revisi)); ?>" target="_blank">Download</a>
                                    <?php else: ?>
                                        
                                    <?php endif; ?>
                                </td>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("komisi.agenda-komisi.layouts.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work&Internship\FH\main\coba1_backend\resources\views/komisi/transparansi/list_revisi.blade.php ENDPATH**/ ?>