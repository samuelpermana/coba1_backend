<link href="<?php echo e(URL::asset("cms/faq/styleindex.css")); ?>" rel="stylesheet">

<?php $__env->startSection("content"); ?>
  <h1>FAQs</h1><br>

  <?php if(session("success")): ?>
    <div class="alert alert-success">
      <?php echo e(session("success")); ?>

    </div><br>
  <?php endif; ?>

  <a class="btn btn-primary mb-2" href="<?php echo e(route("admin.faq.create")); ?>">Add FAQ</a><br><br>

  <?php if(count($faqs) > 0): ?>
    <table class="item" border="1">
      <thead>
        <tr>
          <th scope="col">Question</th>
          <th scope="col">Answer</th>
          <th scope="col">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($faq->question); ?></td>
            <td><?php echo e($faq->answer); ?></td>
            <td>
              <a href="<?php echo e(route("admin.faq.edit", $faq->id)); ?>">Edit</a> |
              <form class="d-inline" action="<?php echo e(route("admin.faq.destroy", $faq->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field("DELETE"); ?>
                <button type="submit" onclick="return confirm('Are you sure you want to delete this FAQ?')">Delete</button>
              </form>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  <?php else: ?>
    <p>No FAQs found</p>
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("cms.layouts.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work&Internship\FH\main\coba1_backend\resources\views/cms/faq/index.blade.php ENDPATH**/ ?>