<?php $__env->startSection("content"); ?>
<link href="<?php echo e(asset("styletransparansi.css")); ?>" rel="stylesheet">
    <div class="container">
        <div class="header-revisi">
            <h1>Daftar Revisi Proposal</h1>
            <h2><?php echo e($proposal->judul); ?></h2>
        </div>

        <section class="table__body">
            <table>
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Komentar</th>
                        <th>Direvisi Oleh</th>
                        <th>Waktu Revisi</th>
                        <th>File di Revisi</th>
                        <th>Judul Lama</th>
                        <th>Deskripsi Lama</th>
                        <th>File Lama</th>
                        <th>Judul Baru</th>
                        <th>Deskripsi Baru</th>
                        <th>File Baru</th>
                        <th>Upload Hasil Revisi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $revisiProposals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $revisi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td><?php echo e($revisi->komentar); ?></td>
                            <td><?php echo e($revisi->revisedBy->name); ?></td>
                            <td><?php echo e($revisi->created_at->format('d M Y H:i:s')); ?></td>
                            <td><a href="<?php echo e(Storage::url($revisi['file_revisi'])); ?>" target="_blank">Download</a></td>
                            <?php $__currentLoopData = $riwayatRevisi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $riwayat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($riwayat->revisi_id == $revisi->id): ?>
                                <td><?php echo e($riwayat->judul_lama); ?></td>
                                <td><?php echo e($riwayat->deskripsi_lama); ?></td>
                                <td><a href="<?php echo e(Storage::url($riwayat->file_lama)); ?>" target="_blank">Download</a></td>
                                <td><?php echo e($riwayat->judul_hasil_revisi ?? ''); ?></td>
                                <td><?php echo e($riwayat->deskripsi_hasil_revisi ?? ''); ?></td>
                                <td>
                                    <?php if($riwayat->file_hasil_revisi): ?>
                                        <a href="<?php echo e(Storage::url($riwayat->file_hasil_revisi)); ?>" target="_blank">Download</a>
                                    <?php else: ?>
                                        
                                    <?php endif; ?>
                                </td>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <td>
                                <?php if($revisi->is_revision_done_by_ormawa == 0): ?>
                                    <a href="<?php echo e(route('ormawa.create_revisi', ['proposalId' => $proposal->id, 'revisiId' => $revisi->id])); ?>" >Upload Revisi</a>
                                <?php elseif($revisi->is_revision_done_by_ormawa == 1): ?>
                                    Revisi berhasil terkirim
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("ormawa.layouts.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work&Internship\FH\main\coba1_backend\resources\views/ormawa/list_revisi.blade.php ENDPATH**/ ?>