<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['action', 'data']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['action', 'data']); ?>
<?php foreach (array_filter((['action', 'data']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="modal-dialog">
    <form id="form-action" action="<?php echo e($action); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title">Membuat Aktivitas Legislasi</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <?php echo e($slot); ?>

        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Save changes</button>
        </div>
        </div>
    </form>
  </div><?php /**PATH D:\Work&Internship\FH\main\coba1_backend\resources\views/components/modal-action.blade.php ENDPATH**/ ?>