<?php $__env->startSection("content"); ?>
  
  <link href="<?php echo e(URL::asset("cms/roomSchedule/stylecreate.css")); ?>" rel="stylesheet">

  <body>
    <h1>Create Room Schedule</h1>

    <?php if($errors->any()): ?>
      <div style="color: red;">
        <ul>
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
    <?php endif; ?>

    <form action="<?php echo e(route("admin.room-schedules.store")); ?>" method="POST">
      <?php echo csrf_field(); ?>
      <label for="room_id">Room:</label><br>
      <select id="room_id" name="room_id">
      <option value="" selected disabled>Pilih Ruangan</option>
      <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($room->id); ?>"><?php echo e($room->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select><br><br>

      <label for="date">Date:</label><br>
      <input id="date" name="date" type="date"><br><br>

      <label for="start_time">Start Time:</label><br>
      <input id="start_time" name="start_time" type="time"><br><br>
      
      <label for="end_time">End Time:</label><br>
      <input id="end_time" name="end_time" type="time"><br><br>
      
      <label for="booked_by">Booked By:</label><br>
      <input id="booked_by" name="booked_by" type="text"><br><br>

      <button type="submit">Submit</button>
    </form>
  </body>
  
<?php $__env->stopSection(); ?>

<?php echo $__env->make("cms.layouts.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work&Internship\FH\main\coba1_backend\resources\views/cms/roomSchedule/create.blade.php ENDPATH**/ ?>