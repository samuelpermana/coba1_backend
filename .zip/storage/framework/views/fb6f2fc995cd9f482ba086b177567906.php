<?php $__env->startSection("content"); ?>
  
  <link href="<?php echo e(URL::asset("cms/jdih/styleedit.css")); ?>" rel="stylesheet">

  <body>
    <h1>Edit JDIH Record</h1>

    <?php if(session("success")): ?>
      <div style="color: green;"><?php echo e(session("success")); ?></div>
    <?php endif; ?>

    <form class="custom-form" action="<?php echo e(route("admin.jdih.update", ["id" => $jdihRecord->id])); ?>" method="POST" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>
      <input name="_method" type="hidden" value="PUT">

      <label for="tahun">Tahun:</label><br>
      <input pattern="[0-9]*" class="custom-input" id="tahun" name="tahun" type="text" value="<?php echo e($jdihRecord->tahun); ?>"><br>

      <label for="jenis_jdih_id">Jenis Peraturan:</label><br>
      <select id="jenis_jdih_id" name="jenis_jdih_id" required>
        <option value="" selected disabled>Select Jenis Peraturan</option>
        <?php $__currentLoopData = $jenisJDIH; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($jenis->id); ?>" <?php echo e($jenis->id == $jdihRecord->jenis_jdih_id ? 'selected' : ''); ?>><?php echo e($jenis->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select><br>

      <label for="nama_peraturan">Nama Peraturan:</label><br>
      <input class="custom-input" id="nama_peraturan" name="nama_peraturan" type="text" value="<?php echo e($jdihRecord->nama_peraturan); ?>"><br>

      <label for="tanggal_disahkan">Tanggal Disahkan:</label><br>
      <input class="custom-input" id="tanggal_disahkan" name="tanggal_disahkan" type="date" value="<?php echo e($jdihRecord->tanggal_disahkan); ?>"><br>

      <label for="peraturan">Peraturan:</label><br>
      <textarea accept="application/pdf" class="custom-input" id="peraturan" name="peraturan"><?php echo e($jdihRecord->peraturan); ?></textarea><br>

      <label for="status_peraturan">Status Peraturan:</label><br>
      <input accept="application/pdf" class="custom-input" id="status_peraturan" name="status_peraturan" type="text" value="<?php echo e($jdihRecord->status_peraturan); ?>"><br>

      <label for="file_peraturan">File Peraturan:</label><br>
      <?php if($jdihRecord->file_peraturan): ?>
        <p><a href="<?php echo e(Storage::url($jdihRecord->file_peraturan)); ?>" target="_blank" class="custom-link">Download File Peraturan Lama</a></p>
      <?php endif; ?>
      <input accept="application/pdf" class="custom-bae" id="file_peraturan" name="file_peraturan" type="file"><br>

      <label for="file_naskah">File Naskah Akademik:</label><br>
      <?php if($jdihRecord->file_naskah): ?>
        <p><a href="<?php echo e(Storage::url($jdihRecord->file_naskah)); ?>" target="_blank" class="custom-link">Download File Naskah Lama</a></p>
      <?php endif; ?>
      <input accept="application/pdf" class="custom-bae" id="file_naskah" name="file_naskah" type="file"><br>

      <label for="file_inventarisasi">File DIM:</label><br>
      <?php if($jdihRecord->file_inventarisasi): ?>
        <p><a href="<?php echo e(Storage::url($jdihRecord->file_inventarisasi)); ?>" target="_blank" class="custom-link">Download File Inventarisasi Lama</a></p>
      <?php endif; ?>
      <input accept="application/pdf" class="custom-bae" id="file_inventarisasi" name="file_inventarisasi" type="file"><br>

      <label for="file_lainnya">File Lainnya <small style="font-size: 0.8em;">(centang jika ingin menghapus file)</small>:</label><br>
      <?php if($jdihRecord->file_lain->isNotEmpty()): ?>
        <ul>
          <?php $__currentLoopData = $jdihRecord->file_lain; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
              <a href="<?php echo e(Storage::url($file->nama_file)); ?>" target="_blank" class="custom-link">Download File Lainnya <?php echo e($loop->iteration); ?></a>
              <input  class="custom-link" type="checkbox" name="file_to_delete[]" value="<?php echo e($file->id); ?>"> <br>
            </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      <?php endif; ?>
      <input accept="application/pdf" class="custom-bae" id="file_lainnya" name="file_lainnya[]" type="file" multiple><br>

      <button class="btn" type="submit">Update</button>
    </form>

    <a href="<?php echo e(route("admin.jdih.index")); ?>">Back to JDIH Records</a>
    <!-- Include your additional content, styles, and scripts as needed -->
  </body>
  
<?php $__env->stopSection(); ?>

<?php echo $__env->make("cms.layouts.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work&Internship\FH\main\coba1_backend\resources\views/cms/jdih/edit.blade.php ENDPATH**/ ?>