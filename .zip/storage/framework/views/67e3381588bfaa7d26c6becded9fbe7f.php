<?php if (isset($component)) { $__componentOriginalc595ac72195ffc4be92ee53697ecf854 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc595ac72195ffc4be92ee53697ecf854 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal-action','data' => ['action' => ''.e($action).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal-action'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['action' => ''.e($action).'']); ?>
  <?php if($data->id): ?>
    <?php echo method_field("put"); ?>
  <?php endif; ?>
  <div class="row">
    <div class="col-6">
      <div class="mb-3">
        <input class="form-control datepicker" name="start_date" type="text" value="<?php echo e($data->start_date ?? request()->start_date); ?>" readonly>
      </div>
    </div>
    <div class="col-6">
      <div class="mb-3">
        <input class="form-control datepicker" name="end_date" type="text" value="<?php echo e($data->end_date ?? request()->end_date); ?>" readonly>
      </div>
    </div>
    <div class="col-12">
      <div class="mb-3">
        <textarea class="form-control" name="title"><?php echo e($data->title); ?></textarea>
      </div>
    </div>
    <div class="col-12">
      <div class="mb-3">
        <div class="form-check form-check-inline">
          <input class="form-check-input" id="category-success" name="category" type="radio" value="success" <?php echo e($data->category == "success" ? "checked" : null); ?>>
          <label class="form-check-label" for="category-success">Rapat Komisi</label>
        </div>
        <div class="form-check form-check-inline">
          <input class="form-check-input" id="category-danger" name="category" type="radio" value="danger" <?php echo e($data->category == "danger" ? "checked" : null); ?>>
          <label class="form-check-label" for="category-danger">Rapat Badan</label>
        </div>
        <div class="form-check form-check-inline">
          <input class="form-check-input" id="category-warning" name="category" type="radio" value="warning" <?php echo e($data->category == "warning" ? "checked" : null); ?>>
          <label class="form-check-label" for="category-warning">Rapat Senator</label>
        </div>
        <div class="form-check form-check-inline">
          <input class="form-check-input" id="category-info" name="category" type="radio" value="info" <?php echo e($data->category == "info" ? "checked" : null); ?>>
          <label class="form-check-label" for="category-info">Sidang Pleno</label>
        </div>
        <div class="form-check form-check-inline">
          <input class="form-check-input" id="category-info" name="category" type="radio" value="disabled" <?php echo e($data->category == "info" ? "checked" : null); ?>>
          <label class="form-check-label" for="category-info">Sidang Paripurna</label>
        </div>
      </div>
    </div>
    <div class="col-12">
      <div class="mb-3">
        <div class="form-check form-switch">
          <input class="form-check-input" id="flexSwitchCheckDefault" name="delete" type="checkbox" role="switch">
          <label class="form-check-label" for="flexSwitchCheckDefault">Delete</label>
        </div>
      </div>
    </div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc595ac72195ffc4be92ee53697ecf854)): ?>
<?php $attributes = $__attributesOriginalc595ac72195ffc4be92ee53697ecf854; ?>
<?php unset($__attributesOriginalc595ac72195ffc4be92ee53697ecf854); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc595ac72195ffc4be92ee53697ecf854)): ?>
<?php $component = $__componentOriginalc595ac72195ffc4be92ee53697ecf854; ?>
<?php unset($__componentOriginalc595ac72195ffc4be92ee53697ecf854); ?>
<?php endif; ?>
<?php /**PATH D:\Work&Internship\FH\main\coba1_backend\resources\views/CMS-event-form.blade.php ENDPATH**/ ?>