<?php $__env->startSection("content"); ?>
  

  <link href="<?php echo e(URL::asset("cms/aktivitasSenat/styleindex.css")); ?>" rel="stylesheet">

  <body>
    <h1>Aktivitas Senat List</h1>

    <a class="btn btn-primary" href="<?php echo e(route("admin.aktivitasSenat.create")); ?>">Create Aktivitas Senat</a>

    <table class="table item" border="1">

      <thead>
        <tr>
          <th>ID</th>
          <th>Judul</th>
          <th>Isi Teks</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $aktivitasSenats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aktivitasSenat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($aktivitasSenat->id); ?></td>
            <td><?php echo e($aktivitasSenat->judul); ?></td>
            <td><?php echo e($aktivitasSenat->isi_teks); ?></td>
            <td>

              <a class="btn-info" href="<?php echo e(route("admin.aktivitasSenat.show", ["id" => $aktivitasSenat->id])); ?>">Show</a>
              <a class="btn-warning" href="<?php echo e(route("admin.aktivitasSenat.edit", ["id" => $aktivitasSenat->id])); ?>">Edit</a>
              <form style="display:inline" action="<?php echo e(route("admin.aktivitasSenat.destroy", ["id" => $aktivitasSenat->id])); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field("DELETE"); ?>
                <button class="btn-danger" type="submit">Delete</button>

              </form>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>

    <!-- Add your additional HTML content here -->

    <!-- Add your scripts and other body elements here -->
  </body>

  
<?php $__env->stopSection(); ?>

<?php echo $__env->make("cms.layouts.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work&Internship\FH\main\coba1_backend\resources\views/cms/aktivitasSenat/index.blade.php ENDPATH**/ ?>