<?php $__env->startSection("content"); ?>
  <link href="stylebankaspirasi.css" rel="stylesheet" />

  <section class="container">
    <h2 class="header">Bank Aspirasi</h2>
    <p class="sub-header">Berisikan tentang kumpulan aspirasi dari mahasiswa beserta jawaban.</p>

    <!-- Sarpras Section -->
    <h2 class="header-BA">Sarana dan Prasarana</h2>
    <div class="pricing">
      <?php if($sarpras->isEmpty()): ?>
        <p class="slobeh">Belum ada data untuk kategori SARPRAS.</p>
      <?php else: ?>
        <?php $__currentLoopData = $sarpras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aspirasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="card">
            <div class="content">
              <h4><?php echo e($aspirasi->message); ?></h4>
            </div>
            <button class="btn3">Selengkapnya</button>
            <div class="panel">
              <p><?php echo e($aspirasi->answer); ?></p>
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
    </div>

    <!-- Birokrasi Section -->
    <h2 class="header-BA">Birokrasi</h2>
    <div class="pricing">
      <?php if($birokrasi->isEmpty()): ?>
        <p class="slobeh">Belum ada data untuk kategori BIROKRASI.</p>
      <?php else: ?>
        <?php $__currentLoopData = $birokrasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aspirasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="card">
            <div class="content">
              <h4><?php echo e($aspirasi->message); ?></h4>
            </div>
            <button class="btn3">Selengkapnya</button>
            <div class="panel">
              <p><?php echo e($aspirasi->answer); ?></p>
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
    </div>

    <!-- Akademik Section -->
    <h2 class="header-BA">Akademik</h2>
    <div class="pricing">
      <?php if($akademik->isEmpty()): ?>
        <p class="slobeh">Belum ada data untuk kategori AKADEMIK.</p>
      <?php else: ?>
        <?php $__currentLoopData = $akademik; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aspirasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="card">
            <div class="content">
              <h4><?php echo e($aspirasi->message); ?></h4>
            </div>
            <button class="btn3">Selengkapnya</button>
            <div class="panel">
              <p><?php echo e($aspirasi->answer); ?></p>
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
    </div>
    <script src="js-bankaspirasi.js"></script>
    
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work&Internship\FH\main\coba1_backend\resources\views/bankaspirasi.blade.php ENDPATH**/ ?>