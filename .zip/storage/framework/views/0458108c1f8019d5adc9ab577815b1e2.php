<?php $__env->startSection("content"); ?>

  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/remixicon/3.5.0/remixicon.min.css" rel="stylesheet" />

    <link href="<?php echo e(asset("styledetailjdih.css")); ?> " rel="stylesheet" />
    <title>JDIH</title>
  </head>

  <body>

    <div class="pricing-JD">
      <div class="card-JD1">
        <div class="content">
          <table class="content-table">
            <thead>
            </thead>
            <tbody>
              <tr>
                <td>Tipe Dokumen</td>
                <td><?php echo e($jdihRecord->jenis_peraturan); ?></td>
              </tr>
              <tr class="active-row">
                <td>Judul</td>
                <td><?php echo e($jdihRecord->nama_peraturan); ?></td>
              </tr>
              <tr>
                <td>Tanggal Disahkan</td>
                <td><?php echo e($jdihRecord->tanggal_disahkan); ?></td>
              </tr>
              <tr>
                <td>Peraturan</td>
                <td><?php echo e($jdihRecord->peraturan); ?></td>
              </tr>
              <tr>
                <td>Status Peraturan</td>
                <td><?php echo e($jdihRecord->status_peraturan); ?></td>
              </tr>
              <tr>
                <td>File Peraturan</td>
                <td><a href="<?php echo e(Storage::url($jdihRecord->file_peraturan)); ?>" target="_blank">Download</a></td>
                </td>
              </tr>
              <tr>
                <td>File Naskah Akademik</td>
                <td><a href="<?php echo e(Storage::url($jdihRecord->file_naskah)); ?>" target="_blank">Download</a></td>
              </tr>
              <tr>
                <td>File DIM</td>
                <td><a href="<?php echo e(Storage::url($jdihRecord->file_inventarisasi)); ?>" target="_blank">Download</a></td>
              </tr>
              <tr>
                <td>File Lainnya</td>
                <td>
                  <?php if($jdihRecord->file_lain->isNotEmpty()): ?>
                    <ul>
                      <?php $__currentLoopData = $jdihRecord->file_lain; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(Storage::url($file->nama_file)); ?>" target="_blank">Download <?php echo e($loop->iteration); ?></a></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                  <?php else: ?>
                    N/A
                  <?php endif; ?>
                </td>
              </tr>
              <!-- <tr>
                      <td>Download File</td>
                      <td><a href="img/filetransparan.svg" download>
                        <span class="blue">
                          <img class="imageperma" src="img/filetransparan.svg" alt=""/>
                        </span>
                      </a>
                      </td>
                    </tr> -->
            </tbody>
          </table>
        </div>
      </div>
    </div>

  </body>
  <script src="<?php echo e(asset("script7.js")); ?> "></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work&Internship\FH\main\coba1_backend\resources\views/detailJDIH.blade.php ENDPATH**/ ?>