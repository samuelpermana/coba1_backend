<?php $__env->startSection("content"); ?>
  

  <link href="<?php echo e(URL::asset("cms/rooms/styleindex.css")); ?>" rel="stylesheet">

  <body>
    <h1>Rooms List</h1>

    <?php if(session("success")): ?>
      <div style="color: green;"><?php echo e(session("success")); ?></div>
    <?php endif; ?>

    <button class="btn"><a href="<?php echo e(route("admin.rooms.create")); ?>">Create New Room</a></button>

    <ul>
      <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="list">
          <table>
            <tr>
              <th></th>
              <th></th>
              <th></th>
            </tr>
            <tr>
              <td><span class="list-room"><?php echo e($room->name); ?> </span></td>
              <td><button><a href="<?php echo e(route("admin.rooms.edit", $room->id)); ?>">Edit</a></button> |
                <form style="display: inline-block;" action="<?php echo e(route("admin.rooms.destroy", $room->id)); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field("DELETE"); ?>
                  <button type="submit" onclick="return confirm('Are you sure you want to delete this room?')">Delete</button>
                </form>
              </td>
            </tr>
          </table>
        </li>
        </table>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </body>

  
<?php $__env->stopSection(); ?>

<?php echo $__env->make("cms.layouts.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work&Internship\FH\main\coba1_backend\resources\views/cms/rooms/index.blade.php ENDPATH**/ ?>