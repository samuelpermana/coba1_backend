<?php $__env->startSection("content"); ?>
  

  <link href="<?php echo e(URL::asset("cms/transparansi/styleindex.css")); ?>" rel="stylesheet">

  <h1>Persetujuan Proposal</h1>

  <?php if(session("success")): ?>
    <div style="color: green;"><?php echo e(session("success")); ?></div>
  <?php endif; ?>

  <table class="item" border="1">
    <thead>
      <tr>
        
        <th>Ormawa</th>
        <th>Tanggal Diajukan</th>
        <th>Judul</th>
        <th>Deskripsi</th>
        <th>Dokumen</th>
        <th>Progress Tahap Persetujuan </th>
        <th>Status Persetujuan </th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      <tr></tr>
      <?php $__currentLoopData = $proposalData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proposal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($proposal["nama_pengaju"]); ?></td>
          <td><?php echo e($proposal["created_at"]); ?></td>
          <td><?php echo e($proposal["judul"]); ?></td>
          <td><?php echo e($proposal["deskripsi"]); ?></td>
          <td><a href="<?php echo e(Storage::url($proposal["file_proposal"])); ?>"target="_blank">
              <span class="blue"><img class="star-img" src="img/filetransparan.svg" alt="" /></span>
            </a></td>

          <td><?php echo e($proposal["status"]); ?></td>
          <td><?php echo e($proposal["status_persetujuan"]); ?></td>
          <td>
    <?php if($proposal["status_persetujuan"] != 'rejected'): ?>
        <form action="<?php echo e(route("admin.proposal.update-komisi", $proposal["id"])); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field("PUT"); ?>
            <select class="select" name="komisi_checked_by" <?php echo e($proposal["komisi_checked_by"] ? 'disabled' : ''); ?>>
                <?php if($proposal["komisi_checked_by"] == null): ?>
                    <option value="" disabled selected>pilih</option>
                <?php endif; ?>
                <?php $__currentLoopData = $komisiUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($user->id); ?>" <?php echo e($proposal["komisi_checked_by"] == $user->id ? "selected" : ""); ?>>
                        <?php echo e($user->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php if(!$proposal["komisi_checked_by"]): ?>
                <button class="btn" type="submit">Submit</button>
            <?php endif; ?>
        </form>
    <?php endif; ?>

    <?php if($proposal["status"] == 'admin' && $proposal["status_persetujuan"] == 'rejected'): ?>
        Sudah di reject
    <?php else: ?>
        <?php if($proposal["status_persetujuan"] != 'rejected' && !$proposal["komisi_checked_by"]): ?>
            <form action="<?php echo e(route("admin.proposal.admin-reject", $proposal["id"])); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field("PUT"); ?>
                <button class="btn" type="submit">Reject</button>
            </form>
        <?php endif; ?>
    <?php endif; ?>
</td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
  <script src="<?php echo e(URL::asset("js-rs-index.js")); ?>"></script>

  
<?php $__env->stopSection(); ?>

<?php echo $__env->make("cms.layouts.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work&Internship\FH\main\coba1_backend\resources\views/cms/transparansi/index.blade.php ENDPATH**/ ?>