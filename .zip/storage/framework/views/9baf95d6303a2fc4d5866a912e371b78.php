<?php $__env->startSection("content"); ?>
<link href="<?php echo e(asset("styletransparansi.css")); ?>" rel="stylesheet">
    <section class="container">
        <h2 class="header">Persetujuan Proposal dan LPPK</h2>
        <p class="sub-header">Berisikan tentang data Surat yang sudah diajukan kepada senat </p>
        <a href="<?php echo e(route(auth()->user()->role->role_slug . '.proposal.belum-diperiksa')); ?>"><button type="button" class="trans">Belum diperiksa</button></a>
        <a href="<?php echo e(route(auth()->user()->role->role_slug . '.proposal.direvisi')); ?>"><button type="button" class="trans">Proposal di revisi</button></a>
        <a href="<?php echo e(route(auth()->user()->role->role_slug . '.proposal.disetujui')); ?>"><button type="button" class="trans">Proposal di setujui</button></a>
        <a href="<?php echo e(route(auth()->user()->role->role_slug . '.proposal.ditolak')); ?>"><button type="button" class="trans">Proposal ditolak</button></a>

    <main class="table" id="customers_table">
        <section class="table__header">
            <div class="input-group">
                <input type="search" placeholder="Search Data...">
                <img src="/img/search.png" alt="">
            </div>
            
        </section>
        
        <section class="table__body">
            <table>
                <thead>
                    <tr>
                    <th>Ormawa</th>
                    <th>Tanggal Diajukan</th>
                    <th>Judul</th>
                    <th>Deskripsi</th>
                    <th>Dokumen</th>
                    <th>Progress Tahap Persetujuan </th>
                    <th>Status Persetujuan </th>
                    <th>File Final </th>
                    <th>Actions</th>
                        
                    </tr>
                </thead>
                <tbody>
      <tr></tr>
      <?php $__currentLoopData = $proposalData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proposal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($proposal['nama_pengaju']); ?></td>
          <td><?php echo e($proposal['created_at']); ?></td>
          <td><?php echo e($proposal['judul']); ?></td>
          <td><?php echo e($proposal['deskripsi']); ?></td>
          <td><a href="<?php echo e(Storage::url($proposal['file_proposal'])); ?>"target="_blank>
                  <span class="blue"><img class="star-img" src="/img/filetransparan.svg" alt="" /></span>
              </a></td>
          </td>
          <td><?php echo e($proposal['status']); ?></td>
          <td><?php echo e($proposal['status_persetujuan']); ?></td>
          <td><?php if($proposal['status'] == 'sekjen' && $proposal['status_persetujuan'] == 'approved'): ?>
                                
                                <?php if($proposal['file_final']): ?>
                                    <a href="<?php echo e(Storage::url($proposal['file_final'])); ?>" target="_blank" class="blue">
                                        <img class="star-img" src="/img/filetransparan.svg" alt="" />
                                    </a>
                                <?php else: ?>
                                    belum diupload
                                <?php endif; ?>
                            <?php else: ?>
                                Belum disetujui
                            <?php endif; ?></td>
          <td><a href="<?php echo e(route(auth()->user()->role->role_slug . '.proposal.revisi', $proposal['id'])); ?>" class="btn-warning2 ">Revisi</a></td>

        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
            </table>
        </section>
    </main>
    <script src="js-peminjamanruangan.js"></script>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make("komisi.agenda-komisi.layouts.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work&Internship\FH\main\coba1_backend\resources\views/komisi/transparansi/proposal_direvisi.blade.php ENDPATH**/ ?>