<?php $__env->startSection("content"); ?>
  <link href="<?php echo e(asset("styleajukansurat.css")); ?>" rel="stylesheet">
  

  <div class="container-AJ">
    <h1 class="form-title">Ajukan Surat</h1>
    <form method="POST" action="<?php echo e(route('ormawa.pengajuan_proposal')); ?>" enctype="multipart/form-data">
     <?php echo csrf_field(); ?>
      <div class="main-user-info">
        <div class="user-input-box">
          <label for="judul">Judul Proposal</label>
          <input id="fullName" name="judul" type="text" placeholder="Judul Proposal" required/>
        </div>
        <div class="user-input-box">
          <label for="deskripsi">Deskripsi</label>
          <input id="username" name="deskripsi" type="text" placeholder="Deskripsi" required/>
        </div>

      </div>
      <div class="gender-details-box">
        <span class="gender-title" style="color: #18181b">File</span>
        <div class="mb-3">
        <label for="file_proposal"class="form-label">File Proposal (Format Doc/Docx)</label>
          <input class="form-control" id="formFileMultiple" type="file" accept=".doc, .docx" class="form-control-file" name="file_proposal" required>
        </div>
      </div>
      <div class="form-submit-btn">
        <input type="submit" value="Submit">
      </div>
    </form>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("ormawa.layouts.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work&Internship\FH\main\coba1_backend\resources\views/ormawa/ajukansurat.blade.php ENDPATH**/ ?>