<?php $__env->startSection("content"); ?>
  <link href="<?php echo e(URL::asset("cms/styleaspirasi.css")); ?>" rel="stylesheet">

  <body>
    <h1>Admin CMS - Bank Aspirasi</h1>

    <h2>Data Aspirasi</h2>

    <table class="item" border="1">
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Email</th>
          <th>Angkatan</th>
          <th>ID Line</th>
          <th>Message</th>
          <th>Status</th>
          <th>Tipe ID</th>
          <th>Answer</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $aspirasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aspirasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($aspirasi->id); ?></td>
            <td><?php echo e($aspirasi->name); ?></td>
            <td><?php echo e($aspirasi->email); ?></td>
            <td><?php echo e($aspirasi->angkatan); ?></td>
            <td><?php echo e($aspirasi->id_line); ?></td>
            <td><?php echo e($aspirasi->message); ?></td>
            <td><?php echo e($aspirasi->is_actived ? "Active" : "Inactive"); ?></td>
            <td><?php echo e($aspirasi->tipe_aspirasi_id); ?></td>
            <td><?php echo e($aspirasi->answer); ?></td>
            <td>
              <form action="<?php echo e(route("admin.update", $aspirasi->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field("PUT"); ?>

                <label>Status: </label>
                <select class="btn" name="is_actived">
                  <option value="1" <?php echo e($aspirasi->is_actived ? "selected" : ""); ?>>Active</option>
                  <option value="0" <?php echo e(!$aspirasi->is_actived ? "selected" : ""); ?>>Inactive</option>
                </select>
                <br>

                <label>Tipe ID: </label>
                <select class="btn" name="tipe_aspirasi_id">
                  <option value="1" <?php echo e($aspirasi->tipe_aspirasi_id == 1 ? "selected" : ""); ?>>Sarana Prasarana</option>
                  <option value="2" <?php echo e($aspirasi->tipe_aspirasi_id == 2 ? "selected" : ""); ?>>Birokrasi</option>
                  <option value="3" <?php echo e($aspirasi->tipe_aspirasi_id == 3 ? "selected" : ""); ?>>Akademik</option>
                </select>
                <br>

                <label>Answer: </label>
                <textarea name="answer"><?php echo e($aspirasi->answer); ?></textarea>
                <br>

                <button class="btn" type="submit">Update</button>
              </form>

              <form action="<?php echo e(route("admin.delete", $aspirasi->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field("DELETE"); ?>
                <button class="btn" type="submit">Delete</button>
              </form>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>

  </body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("cms.layouts.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work&Internship\FH\main\coba1_backend\resources\views/cms/aspirasi.blade.php ENDPATH**/ ?>