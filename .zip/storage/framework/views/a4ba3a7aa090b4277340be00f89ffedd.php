<?php $__env->startSection('content'); ?>
<link href="<?php echo e(asset("styleagenda.css")); ?>" rel="stylesheet">
    <div class="container-revisi">
        <div class="header-revisi">
            <h1>List Revisi Proposal</h1>
            <p>Judul Proposal direvisi: <?php echo e($proposal->judul); ?></p>
            <p>Deskripsi Proposal direvisi: <?php echo e($proposal->deskripsi); ?></p>
        </div>

        <form action="<?php echo e(route('ormawa.kirim_revisi', [$proposal->id, $revisiProposal->id])); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group-revisi">
                <label for="judul">Judul Baru:</label>
                <input type="text" class="form-control-revisijudul" id="judul" name="judul" value="<?php echo e($proposal->judul); ?>">
            </div>

            <div class="form-group-revisi">
                <label for="deskripsi">Deskripsi Baru:</label>
                <textarea class="form-control-revisi" id="deskripsi" name="deskripsi" rows="3"><?php echo e($proposal->deskripsi); ?></textarea>
            </div>
            
            <div class="form-group-revisi">
                <label for="file_proposal">Upload File Revisi:</label>
                <input type="file" class="form-control-file-revisi" id="file_proposal" name="file_proposal">
            </div>

            <button type="submit" class="btn btn-primary">Kirim Revisi</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("ormawa.layouts.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work&Internship\FH\main\coba1_backend\resources\views/ormawa/create_revisi.blade.php ENDPATH**/ ?>