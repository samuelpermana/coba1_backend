<?php $__env->startSection("content"); ?>
<link href="<?php echo e(asset("styletransparansi.css")); ?>" rel="stylesheet">
    <section class="container">
        <h2 class="header">TRANSPARANSI SURAT</h2>
        <p class="sub-header">Berisikan tentang data Surat yang sudah diajukan kepada senat </p>
        <a href="ajukansurat"><button type="button" class="trans">Ajukan Surat</button></a>
    <main class="table" id="customers_table">
        <section class="table__header">
            <div class="input-group">
                <input type="search" placeholder="Search Data...">
                <img src="img/search.png" alt="">
            </div>
            
        </section>
        
        <section class="table__body">
            <table>
                <thead>
                    <tr>
                        <th> No </th>
                        <th> Judul Proposal </th>
                        <th> Deskripsi </th>
                        <th> Tanggal </th>
                        <th> Tracking Surat </th>
                        <th> Status </th>
                        <th> Surat </th>
                        <th> Lama Proses</th>
                        <th> Upload File Final</th>
                        
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $proposalData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proposal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td> 1 </td>
                        <td><?php echo e($proposal['judul']); ?></td>
                        <td><?php echo e($proposal['deskripsi']); ?></td>
                        <td><?php echo e($proposal['created_at']); ?> </td>
                        <td>
                        <section class="step-wizard">
                            <ul class="step-wizard-list">
                                <li class="step-wizard-item <?php if($proposal['status'] == 'admin'): ?> current-item <?php endif; ?>">
                                    <span class="progress-count">1</span>
                                    <span class="progress-label">Admin</span>
                                </li>
                                <li class="step-wizard-item <?php if($proposal['status'] == 'komisi'): ?> current-item <?php endif; ?>">
                                    <span class="progress-count">2</span>
                                    <span class="progress-label">Komisi</span>
                                </li>
                                <li class="step-wizard-item <?php if($proposal['status'] == 'badan anggaran'): ?> current-item <?php endif; ?>">
                                    <span class="progress-count">3</span>
                                    <span class="progress-label">Badan Anggaran</span>
                                </li>
                                <li class="step-wizard-item <?php if($proposal['status'] == 'sekjen' && $proposal['status_persetujuan'] != 'approved'): ?> current-item <?php endif; ?>">
                                    <span class="progress-count">4</span>
                                    <span class="progress-label">SekJen</span>
                                </li>



                            </ul>
                        </section>
                    </td>
                    <td><?php echo e($proposal['status_persetujuan']); ?>

                        <?php if($proposal['status_persetujuan'] == 'revised'): ?>
                            <br>
                            <a href="<?php echo e(route('ormawa.proposal.revisi', $proposal['id'])); ?>" target="_blank">Lihat Detail Revisi dan Kirimkan Revisi Proposal</a>
                        <?php endif; ?>
                    </td>

                        <td>
                        <a href="<?php echo e(Storage::url($proposal['file_proposal'])); ?>"target="_blank>
                            <span class="blue"><img class="star-img" src="img/filetransparan.svg" alt="" /></span>
                        </a>
                        </td>  
                        <td>
                            <?php if($proposal['approved_at']): ?>
                               <?php echo e($proposal['lama_proses']); ?>

                            <?php else: ?>
                                Belum disetujui
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($proposal['status'] == 'sekjen' && $proposal['status_persetujuan'] == 'approved'): ?>
                                
                                <?php if($proposal['file_final']): ?>
                                    <a href="<?php echo e(Storage::url($proposal['file_final'])); ?>" target="_blank" class="blue">
                                        <img class="star-img" src="img/filetransparan.svg" alt="" />
                                    </a>
                                <?php else: ?>
                                    
                                    <img class="star-imgfinal" src="img/filetransparan.svg" alt="" />
                                    <form class="finalis"<?php echo e(route('ormawa.upload.file.final', $proposal['id'])); ?>" method="post" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <input class="final" type="file" name="file_final" accept="application/pdf">
                                        <button class="final-upload" type="submit">Upload File Final</button>
                                    </form>
                                <?php endif; ?>
                            <?php else: ?>
                                Belum disetujui
                            <?php endif; ?>
                        </td>



                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </tbody>
            </table>
        </section>
    </main>
    <script src="js-peminjamanruangan.js"></script>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make("ormawa.layouts.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work&Internship\FH\main\coba1_backend\resources\views/ormawa/transparansisurat.blade.php ENDPATH**/ ?>