<?php $__env->startSection('content'); ?>
<link href="<?php echo e(asset("styleagenda.css")); ?>" rel="stylesheet">
    <section class="container7">
        <h2 class="header">Edit Agenda Kerja</h2>
        <form action="<?php echo e(route( auth()->user()->role->role_slug .'.agenda.update', $agenda->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group">
                <label for="nama">Nama Agenda:</label>
                <input type="text" name="nama" class="form-control input-form" id="nama" value="<?php echo e($agenda->nama); ?>" required>
            </div>
            <div class="form-group">
                <label for="deskripsi">Deskripsi:</label>
                <textarea name="deskripsi" class="form-control" id="deskripsi" rows="5" required><?php echo e($agenda->deskripsi); ?></textarea>
            </div>
            <div class="form-group">
                <label for="status">Status:</label>
                <input class="form-check-input" type="checkbox" value="1" name="status" id="status" <?php echo e($agenda->status == 1 ? 'checked' : ''); ?>>
            </div>
            <div class="form-group">
                <label for="file">Dokumen:</label>
                <?php if($agenda->file): ?>
                    <p>File saat ini: <a href="<?php echo e(Storage::url($agenda->file)); ?>" target="_blank">Download</a></p>
                    <input type="checkbox" name="hapus_file" id="hapus_file"> Hapus File
                <?php else: ?>
                    <p>Tidak ada file yang diunggah.</p>
                <?php endif; ?>
                <input type="file" name="file" class="form-control-file input-form" id="file">
            </div>
            <div class="form-group">
                <label for="link">Link:</label>
                <textarea name="link" class="form-control" id="link" rows="5"><?php echo e($agenda->link); ?></textarea>
            </div>
            <div class="form-group">
                <label for="tanggal_pelaksanaan">Tanggal Pelaksanaan:</label>
                <input type="date" name="tanggal_pelaksanaan" class="form-control input-form" id="tanggal_pelaksanaan" value="<?php echo e($agenda->tanggal_pelaksanaan); ?>" >
            </div>
            <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
        </form>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('agenda-badan.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work&Internship\FH\main\coba1_backend\resources\views/agenda-badan/edit-agenda.blade.php ENDPATH**/ ?>