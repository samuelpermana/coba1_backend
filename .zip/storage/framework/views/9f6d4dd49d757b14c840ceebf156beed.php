<?php $__env->startSection("content"); ?>
  <link href="stylefaq.css" rel="stylesheet">

  <section class="container">
    <h2 class="header">FAQ</h2>
    <p class="sub-header">
      Berisikan tentang pertanyaan yang sering diajukan beserta jawaban secara umum.
    </p>
    <?php if($faqs->isEmpty()): ?>
      <p class="sub-header">Belum ada data.</p>
    <?php else: ?>
    <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="tag">
      <div class="tag-divide">
        <button class="accordion"><?php echo e($faq->question); ?></button>
        <div class="panel">
          <p><?php echo e($faq->answer); ?></p>
        </div>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
  </section>

  <script src="js-faq.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work&Internship\FH\main\coba1_backend\resources\views/faq.blade.php ENDPATH**/ ?>