<?php $__env->startSection("content"); ?>
  
  
  <link href="<?php echo e(URL::asset("cms/roomSchedule/styleindex.css")); ?>" rel="stylesheet">

  <h1>Room Schedules</h1>

  <?php if(session("success")): ?>
    <div style="color: green;"><?php echo e(session("success")); ?></div>
  <?php endif; ?>

  <button class="btn"><a href="<?php echo e(route("admin.room-schedules.create")); ?>">Add New Schedule</a></button>

  <table class="item" border="1">
    <thead>
      <tr>
        
        <th>Room</th>
        <th>Date</th>
        <th>Start Time</th>
        <th>End Time</th>
        <th>Booked By</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      <tr></tr>
      <?php $__currentLoopData = $roomSchedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          
          <td><?php echo e($schedule->room->name); ?></td>
          <td><?php echo e($schedule->date); ?></td>
          <td><?php echo e($schedule->start_time); ?></td>
          <td><?php echo e($schedule->end_time); ?></td>
          <td><?php echo e($schedule->booked_by); ?></td>
          <td>
            <a href="<?php echo e(route("admin.room-schedules.edit", $schedule->id)); ?>">Edit</a> |
            <form action="<?php echo e(route("admin.room-schedules.destroy", $schedule->id)); ?>" method="POST">
              <?php echo csrf_field(); ?>
              <?php echo method_field("DELETE"); ?>
              <button class="delete-btn" type="submit" onclick="return confirm('Are you sure?')">Delete</button>
            </form>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
  <script src="<?php echo e(URL::asset("js-rs-index.js")); ?>"></script>

  
<?php $__env->stopSection(); ?>

<?php echo $__env->make("cms.layouts.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work&Internship\FH\main\coba1_backend\resources\views/cms/roomSchedule/index.blade.php ENDPATH**/ ?>