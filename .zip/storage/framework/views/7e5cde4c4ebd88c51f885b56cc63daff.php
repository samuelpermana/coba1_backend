<?php $__env->startSection('content'); ?>
<link href="<?php echo e(asset("styleagenda.css")); ?>" rel="stylesheet">
    <section class="container">
        <h2 class="header">Agenda Kerja</h2>
        <p class="sub-header">Transparansi Agenda Kerja Komisi </p>
        <a href="<?php echo e(route(auth()->user()->role->role_slug . '.agenda.create')); ?>"><button type="button" class="trans">Buat Agenda Kerja</button></a>
    <main class="table" id="customers_table">
        <section class="table__header">
            <div class="input-group">
                <input type="search" placeholder="Search Data...">
                <img src="<?php echo e(asset("img/search.png")); ?>"  alt="">
            </div>
            
        </section>
        
        <section class="table__body">
            <table>
                <thead>
                    <tr>
                        <th> No <span class="icon-arrow">&UpArrow;</span></th>
                        <th> Nama Agenda <span class="icon-arrow">&UpArrow;</span></th>
                        <th> Tanggal Pelaksanaan <span class="icon-arrow">&UpArrow;</span></th>
                        <th> Status <span class="icon-arrow">&UpArrow;</span></th>
                        <th> Deskripsi <span class="icon-arrow">&UpArrow;</span></th>
                        <th> Dokumen <span class="icon-arrow">&UpArrow;</span></th>
                        <th> link <span class="icon-arrow">&UpArrow;</span></th>
                        <th> Action <span class="icon-arrow">&UpArrow;</span></th>
                        
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $agendas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agenda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($agenda->nama); ?></td>
                        <td><?php echo e($agenda->tanggal_pelaksanaan); ?></td>
                        <td><?php echo e($agenda->status); ?></td>
                        <td><?php echo e($agenda->deskripsi); ?></td> <!-- Tambahkan kolom deskripsi di sini -->
                        <td>
                            <?php if($agenda->file): ?>
                                <a href="<?php echo e(Storage::url($agenda->file)); ?>" target="_blank">Download</a>
                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($agenda->link): ?>
                                <a href="<?php echo e($agenda->link); ?>" target="_blank">Link</a>
                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>

                        <td>
                        <a href="<?php echo e(route(auth()->user()->role->role_slug . '.agenda.edit', $agenda->id)); ?>" class="btn btn-primary">Edit</a>
                        <form action="<?php echo e(route(auth()->user()->role->role_slug . '.agenda.destroy', $agenda->id)); ?>" method="POST" style="display: inline-block;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Hapus</button>
                        </form>
                    </td>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </section>
    </main>
    <script src=<?php echo e(asset("script5.js")); ?>></script>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('komisi.agenda-komisi.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work&Internship\FH\main\coba1_backend\resources\views/komisi/agenda-komisi/agendakerja.blade.php ENDPATH**/ ?>