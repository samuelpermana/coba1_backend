<?php $__env->startSection("content"); ?>
  
  <link href="<?php echo e(URL::asset("cms/jdih/stylecreate.css")); ?>" rel="stylesheet">

  <body>
    <h1>Create JDIH Record</h1>

    <?php if(session("success")): ?>
      <div style="color: green;"><?php echo e(session("success")); ?></div>
    <?php endif; ?>

    <form class="custom-form" action="<?php echo e(route("admin.jdih.store")); ?>" method="POST" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>

      <label for="tahun">Tahun:</label>
      <input id="tahun" name="tahun" type="text" pattern="[0-9]*" required><br>

      <label for="jenis_jdih_id">Jenis Peraturan:</label>
      <select id="jenis_jdih_id" name="jenis_jdih_id" required>
        <option value="" selected disabled>Select Jenis Peraturan</option>
        <?php $__currentLoopData = $jenisJDIH; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($jenis->id); ?>"><?php echo e($jenis->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select><br>

      <label for="nama_peraturan">Nama Peraturan:</label>
      <input id="nama_peraturan" name="nama_peraturan" type="text" required><br>

      <label for="tanggal_disahkan">Tanggal Disahkan:</label>
      <input id="tanggal_disahkan" name="tanggal_disahkan" type="date" required><br>

      <label for="peraturan">Peraturan:</label>
      <textarea id="peraturan" name="peraturan" required></textarea><br>

      <label for="status_peraturan">Status Peraturan:</label>
      <input id="status_peraturan" name="status_peraturan" type="text" required><br>

      <label for="file_peraturan">File Peraturan:</label>
      <input name="file_peraturan" type="file"accept="application/pdf">

      <label for="file_naskah">File Naskah Akademik:</label>
      <input name="file_naskah" type="file" accept="application/pdf">

      <label for="file_inventarisasi">File DIM:</label>
      <input name="file_inventarisasi" type="file" accept="application/pdf">

      <label for="file_lainnya">File Lainnya:</label>
      <input name="file_lainnya[]" type="file" multiple accept="application/pdf">

      <button class="btn" type="submit">Create JDIH Record</button>
    </form>

    <a href="<?php echo e(route("admin.jdih.index")); ?>">Back to JDIH Records</a>
    <!-- Include your additional content, styles, and scripts as needed -->
  </body>
  
<?php $__env->stopSection(); ?>

<?php echo $__env->make("cms.layouts.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work&Internship\FH\main\coba1_backend\resources\views/cms/jdih/create.blade.php ENDPATH**/ ?>