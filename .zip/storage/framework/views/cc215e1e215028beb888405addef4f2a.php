<?php $__env->startSection("content"); ?>
  

  <body>
    <h2>Aktivitas Senat Details</h2>


    <div>
      <strong>Judul:</strong> <?php echo e($aktivitasSenat->judul); ?>

    </div>
    <div>
      <strong>Isi Teks:</strong> <?php echo e($aktivitasSenat->isi_teks); ?>

    </div>
    <div>
      <strong>Gambar:</strong>
      <?php if($aktivitasSenat->gambar): ?>
        <img src="<?php echo e(Storage::url($aktivitasSenat->gambar)); ?>" alt="AktivitasSenat Image">
      <?php else: ?>
        No image available
      <?php endif; ?>
    </div>

    <a href="<?php echo e(route("admin.aktivitasSenat.index")); ?>">Back to List</a>

    <!-- Add your additional HTML content here -->

    <!-- Add your scripts and other body elements here -->
  </body>

  
<?php $__env->stopSection(); ?>

<?php echo $__env->make("cms.layouts.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work&Internship\FH\main\coba1_backend\resources\views/cms/aktivitasSenat/show.blade.php ENDPATH**/ ?>