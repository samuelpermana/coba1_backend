<link href="<?php echo e(URL::asset("cms/faq/stylecreate.css")); ?>" rel="stylesheet">
<?php $__env->startSection("content"); ?>
  <h1>Add FAQ</h1>

  <?php if($errors->any()): ?>
    <div class="alert alert-danger">
      <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
  <?php endif; ?>

  <form action="<?php echo e(route("admin.faq.store")); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="form-group">
      <label for="question">Question</label>
      <textarea class="form-control" id="question" name="question" type="text"></textarea>
    </div>
    <div class="form-group">
      <label class="answer" for="answer">Answer</label>
      <textarea class="form-control" id="answer" name="answer" rows="3"></textarea>
    </div>
    <br><button class="btn btn-primary" type="submit">Submit</button>
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("cms.layouts.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work&Internship\FH\main\coba1_backend\resources\views/cms/faq/create.blade.php ENDPATH**/ ?>