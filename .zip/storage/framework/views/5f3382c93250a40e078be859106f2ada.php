<?php $__env->startSection("content"); ?>
  

  <link href="<?php echo e(URL::asset("cms/rooms/stylecreate.css")); ?>" rel="stylesheet">


  <body>
    <h1>Create New Room</h1>

    <?php if($errors->any()): ?>
      <div style="color: red;">
        <ul>
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
    <?php endif; ?>

    <form action="<?php echo e(route("admin.rooms.store")); ?>" method="POST">
      <?php echo csrf_field(); ?>
      <label for="name">Name:</label><br>
      <input id="name" name="name" type="text" required><br><br>

      <button class="btn" type="submit">Create</button>
    </form>
    <div id="back-btn"><a href= "<?php echo e(route("admin.rooms.index")); ?>"><button class="btn">Back</button></a></div>

  </body>

  
<?php $__env->stopSection(); ?>

<?php echo $__env->make("cms.layouts.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work&Internship\FH\main\coba1_backend\resources\views/cms/rooms/create.blade.php ENDPATH**/ ?>