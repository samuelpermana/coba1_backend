<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="stylelogin.css">
    <title>Forgot Password | Senat FH</title>
</head>

<body>

    <div class="container" id="container">
        
        <div class="form">
            <?php if($errors->any()): ?> 
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
            </div>
        <?php endif; ?>
        <?php if(session()->has('status')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('status')); ?>

            </div>
        <?php endif; ?>

        <h2 class="forgot">Forgot Your Password ? </h2>
        <p class="enter">Enter email to request password reset</p>
        <form action ="<?php echo e(route('passwordPost.request')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <label class="email" for="email" class="form-label">Email</label>
            <input type="email" class="form-control" name="email">
            <input type="submit" value="Request Password Reset" class="btn btn-primary w-100 mt-3">
        </form>
    </div>

    
</body>
 
</html><?php /**PATH D:\Work&Internship\FH\main\coba1_backend\resources\views/auth/forgot-password.blade.php ENDPATH**/ ?>