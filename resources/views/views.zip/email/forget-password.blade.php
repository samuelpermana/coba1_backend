<a href="{{ route('passwordReset.request', $token) }}">Reset Password</a>
